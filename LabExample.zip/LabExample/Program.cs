﻿namespace LabExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Console.WriteLine("Enter Id: ");
            emp.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Department Id ");
            emp.DeptId = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter Name: ");
            emp.Name = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            emp.Password = Console.ReadLine();
            Console.WriteLine(emp.Id + " " + emp.Name + " ");
        }
    }
}

public class Employee { 
    private int id;
    public int Id {
        set
        {
            if (value > 0 )
            {
                id = value;
            }
            else
            {
                Console.WriteLine("Invalid Id.!!!!!!!!!!!!!!");
            }
        }

            get { return id; }
        }

    private short deptId;
    public short DeptId
    {
        set
        {
            if (value > 0)
            {
                deptId = value;
            }
            else
            {
                Console.WriteLine("Invalid Id.!!!!!!!!!!!!!!");
            }
        }

        get { return deptId; }
    }

    private string name;

    public string Name
    {
        set
        {
            if(!string.IsNullOrEmpty(value))
            {
                name = value;
                
            }
            else
            {
                Console.WriteLine("Invalid name.!!!!!!!!!!!!!!");
            }
        }
        get { return name; }
    }

    private string password;

    public string Password
    {
        set
        {
            if (!string.IsNullOrEmpty(value))
            {
                password = value;
                
            }
            else
            {
                Console.WriteLine("Invalid Input!!!!");
            }
        }
    }

    private decimal basic;
    public decimal Basic
    {
        set
        {
            if ()
            {
                basic = value;

            }
            else
            {
                Console.WriteLine("Invalid Input!!!!");
            }
        }
    }

}
