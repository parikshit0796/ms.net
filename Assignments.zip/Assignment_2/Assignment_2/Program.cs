﻿namespace Assignment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee("saurabh", 63545, 101);
            Console.WriteLine(emp1);
            Console.WriteLine("Net salary of " + emp1.Name + " is " + emp1.getNetSalary());

         
            Employee emp2 = new Employee("chandan", 26841);
            Console.WriteLine(emp2);
            Console.WriteLine("Net salary of " + emp2.Name + " is " + emp2.getNetSalary());

            Employee emp3 = new Employee("parikshit");
            Console.WriteLine(emp3);
            Employee emp4 = new Employee();
            Console.WriteLine(emp4);
            Console.WriteLine("Net salary of " + emp3.Name + " is " + emp3.getNetSalary());
        }
    }

    public class Employee
    {
        public static int employeeId;

        public Employee(string name = "Amol", decimal basic = 5000, short deptNo = 20)
        {
            Name = name;
            employeeId++;
            empId = employeeId;
            Basic = basic;
            DeptNo = deptNo;
        }

        private string name;

        public string Name
        {
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    name = value.Trim();
                }
                else
                {
                    Console.WriteLine("Name cant be blank...!!!!!!!!!");
                }
            }

            get { return name; }
        }

        private int empId;

        public int EmpId
        {
            get { return empId; }
        }

        private decimal basic;
        public decimal Basic
        {
            set
            {
                if (value > 0 && value <= 100000)
                {
                    basic = value;
                }
                else
                {
                    Console.WriteLine("Base salary must within 0 to 100000 range");
                }
            }
            get { return basic; }
        }

        private short deptNo;

        public short DeptNo
        {
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    Console.WriteLine("Department number must not be zero");
                }
            }
            get { return deptNo; }
        }

        public decimal getNetSalary()
        {
            decimal percent = 1.1m;
            decimal total = Decimal.Multiply(basic, percent);
            return total;
        }

        public override string ToString()
        {
            return "Employee ID :" + empId + " Name: " + name + " Basic Salary: " + basic + " Department ID: " + deptNo + " ";
        }

    }
}