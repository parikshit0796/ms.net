﻿using System.ComponentModel.Design;
using System.Net;

namespace Assignment_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the name of enolpyee :");
                string? NAME = Console.ReadLine();

               Console.WriteLine("Enter the salary of employee :");
               decimal BASIC = Convert.ToDecimal(Console.ReadLine());
       
                Console.WriteLine("Enter the Department No :");
                short DEPTNO = Convert.ToInt16(Console.ReadLine());

                Employee emp1 = new Employee(NAME, BASIC, DEPTNO);
                Console.WriteLine(emp1);
            }catch(ApplicationException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);    
            }
            
        }
    }


        public  class Employee
        {
            public static int employeeId;

            public Employee(string name , decimal basic , short deptNo )
            {
                Name = name;
                employeeId++;
                empId = employeeId;
                Basic = basic;
                DeptNo = deptNo;
            }

        
        private string? name;

        public string? Name
        {
            get { return name; }
            set
            {
                if ( string.IsNullOrEmpty(value))
                {
                    throw new InvalidInput("employee must not be zero....!!!!!!!!!!!!!");
                }
                else
                {
                    name = value.Trim();
                   
                }
            }
        }

        private int empId;

        public int EmpId
        {
            get { return empId; }
            set {
                if (value !=0)
                {
                    basic = value;
                }
                else
                {
                    throw new InvalidInput("employee must not be zero....!!!!!!!!!!!!!");
                }
            }
        }

        private decimal basic;

        public decimal Basic
        {
            get { return basic; }
            set
            {
                if (value > 1000)
                {
                    basic = value;
                }
                else
                {
                    throw new InvalidInput("Salary below limit....!!!!!!!!!!!!!");
                }
            }
        }        

        private short deptNo;

        public short DeptNo
        {
            get { return deptNo; }
            set {
                if (value != 0)
                {
                    basic = value;
                }
                else
                {
                    throw new InvalidInput("Department must not be zero....!!!!!!!!!!!!!");
                }
            }
        }
          
            public override string ToString()
            {
                return "Employee ID :" + empId + " Name: " + name + " Basic Salary: " + basic + " Department ID: " + deptNo + " ";
            }
        }

        public class InvalidInput : ApplicationException 
        {
        public InvalidInput(string message) : base(message)
        {

        }
            
    }
    }
    