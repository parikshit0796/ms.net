﻿namespace Assignment_4A
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of batches : ");
            int Batches = Convert.ToInt32(Console.ReadLine());
            int students = 0;
            int[][] arr = new int[Batches][];
            for (int i = 0; i < Batches; i++)
            {
                Console.WriteLine($"Enter number of students for batch[{i}] : ");
                students = Convert.ToInt32(Console.ReadLine());

                arr[i] = new int[students];
                for (int j = 0; j < students; j++)
                {
                    Console.WriteLine($"Enter marks for batch[{i}] student[{j}] : ");
                    int marks = Convert.ToInt32(Console.ReadLine());
                    arr[i][j] = marks;


                }
            }


            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {

                    Console.WriteLine($"marks for batch {i} student {j} are : " + arr[i][j]);

                }
            }
        }
    }

    public class CDAC
    {
        public CDAC(int batches, int students)
        {
            Console.WriteLine("Inside cdac constructor");
            this.Batches = batches;
            this.Students = students;
        }

        public int batches;
        public int Batches
        {
            set
            {
                if (value > 0)
                {
                    batches = value;
                }
                else
                {
                    Console.WriteLine("Batches cannot be 0!"); ;
                }
            }
            get
            {
                return batches;
            }
        }

        public int students;
        public int Students
        {
            set
            {
                if (value > 0)
                {
                    students = value;
                }
                else
                {
                    Console.WriteLine("Students cannot be 0!"); ;
                }
            }
        }

        public void display()
        {
            Console.WriteLine();
        }
    }
    }
