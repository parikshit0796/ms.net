﻿namespace Assignment_4B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Question1();
        }
        static void Question1()
        {
            Employee[] arr = new Employee[2];
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Enter employee Name: ");
                string ?name = Console.ReadLine();
                Console.WriteLine("Enter employee salary: ");
                decimal salary = Convert.ToDecimal(Console.ReadLine());
                arr[i] = new Employee(name, salary);
            }
            Employee highestPaid = null;
            decimal maxSal = 0;
            foreach (Employee emp in arr)
            {
                if (emp.EmpSalary > maxSal)
                {
                    maxSal = emp.EmpSalary;
                    highestPaid = emp;
                }
            }
            Console.WriteLine("Employee with highest salary is " + highestPaid);

            Console.WriteLine("Enter Emp Id to search for an employee: ");
            int id = int.Parse(Console.ReadLine());
            foreach (Employee emp in arr)
            {
                if (id == emp.EmpId)
                {
                    Console.WriteLine("Employee found: " + emp);

                }
            }
        }
    }
    public class Employee
    {
        private int empId;
        public int EmpId
        {
            get
            { return empId; }
        }
        private string empName;
        private decimal empSalary;
        private static int counter;

        public Employee(string empName, decimal empSalary)
        {
            this.empId = ++counter;
            this.EmpName = empName;
            this.EmpSalary = empSalary;
        }
        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }
        public decimal EmpSalary
        {
            get { return empSalary; }
            set { empSalary = value; }
        }



        public override string ToString()
        {
            return "employee Id: " + empId + " Name: " + empName + " Salary: " + empSalary;
        }

    }
}