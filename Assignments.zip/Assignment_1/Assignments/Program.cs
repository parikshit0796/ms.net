﻿using System.Runtime.Intrinsics.X86;
using System.Xml.Linq;

namespace Assignments
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            Console.WriteLine("Enter the name ");
            emp1.Name = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter basic salary");
            emp1.Basic = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Enter Department Number");
            emp1.DeptNo = Convert.ToInt16(Console.ReadLine());


            Console.WriteLine("Employee ID :" +emp1.EmpId  + " Name: " + emp1.Name + " Basic Salary: " + emp1.Basic + " Department ID: " +     emp1.DeptNo +  "Net salary of " + emp1.Name + " is : " + emp1.getNetSalary());

        }
    }

    public class Employee
    {
        public static int employeeId;

        public Employee()
        {
            employeeId++;
            empId = employeeId;
        }

        private string name;

        public string Name
        {
            set
            {
                if(! string.IsNullOrEmpty(value) )
                {
                    name = value.Trim();
                }
                else
                {
                    Console.WriteLine("Name cant be blank...!!!!!!!!!");
                }
            }

            get { return name; }
        }

        private int empId;

        public  int EmpId
        {
            get { return   empId; }
        }

        private decimal basic;
        public  decimal Basic
        {
            set
            {
                if (value > 0 && value <= 100000)
                {
                    basic = value;
                }
                else
                {
                    Console.WriteLine("Base salary must within 0 to 100 range");
                }
            }
            get { return basic; }
        }

        private short deptNo;

        public  short DeptNo
        {
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    Console.WriteLine("Department number must not be zero");
                }
            }
            get { return deptNo; }
        }

        public decimal getNetSalary()
        {
            decimal percent = 1.1m;
            decimal total = Decimal.Multiply(basic, percent);
            return total;
        }
        public override string ToString()
        {
            return "Employee ID :" + empId + " Name: " + name + " Basic Salary: " + basic + " Department ID: " + deptNo + " ";
        }
    }
}