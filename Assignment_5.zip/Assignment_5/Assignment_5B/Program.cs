﻿namespace Assignment_5B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the size of array");
            int size = Convert.ToInt32(Console.ReadLine());
            Employee[] emps = new Employee[size];

            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("Enter the details :  Employee Id, Name, Salary, Department No");
                int ID = Convert.ToInt32(Console.ReadLine());
                string? NAME = Console.ReadLine();
                decimal BASIC = Convert.ToDecimal(Console.ReadLine());
                short DEPTNO = Convert.ToInt16(Console.ReadLine());

                emps[i] = new Employee(ID, NAME, BASIC, DEPTNO);
            };

            List<Employee> list = new List<Employee>(emps);
            Console.WriteLine("Converted List :");
            foreach (Employee emp in list)
            {
                Console.WriteLine(emp.Name + " " + emp.EmpId + " " + emp.Basic + " " + emp.DeptNo);
            }
        }
    }

    public class Employee
    {
        public Employee(int empId, string? name, decimal basic, short deptNo)
        {
            EmpId = empId;
            Name = name;
            Basic = basic;
            DeptNo = deptNo;
        }

        private string? name;

        public string? Name
        {
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    name = value.Trim();
                }
                else
                {
                    Console.WriteLine("Name cant be blank...!!!!!!!!!");
                }
            }

            get { return name; }
        }

        private int empId;
        public int EmpId
        {
            get { return empId; }
            set
            {
                if (value > 0)
                {
                    empId = value;
                }
                else
                {
                    Console.WriteLine("Name cant be blank...!!!!!!!!!");
                }
            }
        }

        private decimal basic;
        public decimal Basic
        {
            set
            {
                if (value > 0 && value <= 100000)
                {
                    basic = value;
                }
                else
                {
                    Console.WriteLine("Base salary must within 0 to 100000 range");
                }
            }
            get { return basic; }
        }

        private short deptNo;
        public short DeptNo
        {
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    Console.WriteLine("Department number must not be zero");
                }
            }
            get { return deptNo; }
        }

        public override string ToString()
        {
            return "Employee ID :" + empId + " Name: " + name + " Basic Salary: " + basic + " Department ID: " + deptNo + " ";
        }

        public decimal netSalary()
        {
            decimal percent = 1.1m;
            decimal total = Decimal.Multiply(Basic, percent);
            return total;
        }

    }
}
    