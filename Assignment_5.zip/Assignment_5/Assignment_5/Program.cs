﻿namespace Assignment_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool flag = true;
            SortedList<int, Employee> objDictionary = new SortedList<int, Employee>();
            do
            {
                Console.Write("Enter Id :");
                int EmpId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter name :");
                string? Name = Console.ReadLine();
                Console.Write("Enter salary :");
                decimal Basic = Convert.ToDecimal(Console.ReadLine());
                Console.Write("Enter department no. :");
                short DeptNo = Convert.ToInt16((Console.ReadLine()));

                objDictionary.Add(EmpId, new Employee(EmpId, Name, Basic, DeptNo));

                Console.WriteLine("Select choice to Insert new employee " + "\n" + "Yes / No");
                string? choice = Console.ReadLine().ToLower();

                if (choice == "yes")
                {
                    continue;
                }
                else
                {
                    flag = false;
                }
            } while (flag);


            bool flag2 = true;
            while (flag2)
            {
                Console.WriteLine(" ");
                Console.WriteLine("Enter the choice: 1.Display all employee  2.Display employee with heighest salary " + "\n" +
                                                " 3.Display employee details by Id  4. Dispaly details of employee by Index  5. Exit");

                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:

                        foreach (KeyValuePair<int, Employee> emp in objDictionary)
                        {
                            Console.WriteLine(emp.Key + " " + emp.Value.Name + " " + emp.Value.Basic + " " + emp.Value.DeptNo);
                        }
                        break;

                    case 2:

                        Employee? emp5 = null;
                        decimal salary = 1;
                        foreach (KeyValuePair<int, Employee> emp in objDictionary)
                        {
                            if (salary < emp.Value.Basic)
                            {
                                salary = emp.Value.Basic;
                                emp5 = emp.Value;
                            }

                        }
                        Console.WriteLine(emp5);

                        break;

                    case 3:
                        Console.WriteLine("Enter the existing Emp No :");
                        int value = Convert.ToInt32(Console.ReadLine());
                        bool flag3 = objDictionary.ContainsKey(value);

                        if (flag3)
                        {
                            Employee? emp1 = objDictionary.GetValueOrDefault(value);
                            Console.WriteLine(emp1);

                        }
                        else
                        {
                            Console.WriteLine("Entered key is worng ");

                        }
                        break;

                    case 4:
                        Console.WriteLine("Enter the index : ");
                        Employee objValues = objDictionary.GetValueAtIndex(Convert.ToInt32(Console.ReadLine()));
                        Console.WriteLine(objValues);
                        break;

                    case 5:
                        flag2 = false;
                        break;

                        Console.WriteLine(" ");
                }

            }
        }

        public class Employee
        {


            public Employee(int id, string? name, decimal basic, short deptNo)
            {
                EmpId = id;
                Name = name;
                Basic = basic;
                DeptNo = deptNo;
            }

            private string? name;

            public string? Name
            {
                set
                {
                    if (!string.IsNullOrEmpty(value))
                    {
                        name = value.Trim();
                    }
                    else
                    {
                        Console.WriteLine("Name cant be blank...!!!!!!!!!");
                    }
                }

                get { return name; }
            }

            private int empId;
            public int EmpId
            {
                get { return empId; }
                set
                {
                    if (value > 0)
                    {
                        empId = value;
                    }
                    else
                    {
                        Console.WriteLine("Name cant be blank...!!!!!!!!!");
                    }
                }
            }

            private decimal basic;
            public decimal Basic
            {
                set
                {
                    if (value > 0 && value <= 100000)
                    {
                        basic = value;
                    }
                    else
                    {
                        Console.WriteLine("Base salary must within 0 to 100000 range");
                    }
                }
                get { return basic; }
            }

            private short deptNo;
            public short DeptNo
            {
                set
                {
                    if (value > 0)
                    {
                        deptNo = value;
                    }
                    else
                    {
                        Console.WriteLine("Department number must not be zero");
                    }
                }
                get { return deptNo; }
            }

            public override string ToString()
            {
                return "Employee ID :" + empId + " Name: " + name + " Basic Salary: " + basic + " Department ID: " + deptNo + " ";
            }

            public decimal netSalary()
            {
                decimal percent = 1.1m;
                decimal total = Decimal.Multiply(Basic, percent);
                return total;
            }

        }
    }
}
    
