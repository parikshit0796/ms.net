﻿namespace Assignment_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Manager emp1 = new Manager("Parikshit", 12000, 10, "Project_Manager");
            Console.WriteLine(emp1 +" "+ emp1.Designation);
              
            

            GeneralManager emp2 = new GeneralManager("Parikshit", 12000, 10, "Project_Manager","Higher_Pay");
            Console.WriteLine(emp2 +" "+ emp2.Designation+" " + emp2.Perks);
            
        }
    }

    public interface IDbFunctions
    {
        void Insert();
        void Update();
        void Delete();
    }

    public abstract class Employee:IDbFunctions
    {
        public static int employeeId;

        public Employee(string name = "Amol", decimal basic = 5000, short deptNo = 20)
        {
            Name = name;
            employeeId++;
            empId = employeeId;
            Basic = basic;
            DeptNo = deptNo;
        }

        private string? name;

        public string? Name
        {
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    name = value.Trim();
                }
                else
                {
                    Console.WriteLine("Name cant be blank...!!!!!!!!!");
                }
            }

            get { return name; }
        }

        private int empId;

        public int EmpId
        {
            get { return empId; }
        }

        private decimal basic;
        public decimal Basic
        {
            set
            {
                if (value > 0 && value <= 100000)
                {
                    basic = value;
                }
                else
                {
                    Console.WriteLine("Base salary must within 0 to 100000 range");
                }
            }
            get { return basic; }
        }

        private short deptNo;

        public short DeptNo
        {
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    Console.WriteLine("Department number must not be zero");
                }
            }
            get { return deptNo; }
        }

        public abstract decimal netSalary();

        public void Delete()
        {
            Console.WriteLine("Class1 - IDb.Delete");
        }

        public void Insert()
        {
            Console.WriteLine("Class1 - IDb.Insert");
        }

        public void Update()
        {
            Console.WriteLine("Class1 - IDb.Update");
        }
        public override string ToString()
        {
            return "Employee ID :" + empId + " Name: " + name + " Basic Salary: " + basic + " Department ID: " + deptNo + " ";
        }

    }

    public class Manager : Employee, IDbFunctions
    {
        private string? designation;

        public string? Designation
        {
            get { return designation; }
            set 
            {
                if(! string.IsNullOrEmpty(value)) 
                { 
                    designation = value.Trim();
                }
            else
                { 
                    Console.WriteLine("Designation cant be null");
                }
            }
        }

        public Manager(string name, decimal basic, short deptNo, string? designation) : base(name, basic, deptNo)
        {
            Designation = designation;
            
        }

        public override decimal netSalary()
        {
            decimal percent = 1.1m;
            decimal total = Decimal.Multiply(Basic, percent);
            return total;
        }

        public new void Delete()
        {
            Console.WriteLine("Class2 - IDb.Delete");
        }

        public new void Insert()
        {
            Console.WriteLine("Class2 - IDb.Insert");
        }

        public new void Update()
        {
            Console.WriteLine("Class2 - IDb.Update");
        }
    }


    public class GeneralManager : Manager, IDbFunctions
    {
        private string? perks;
        public string? Perks
        {
            get { return perks; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    perks = value.Trim() ;
                }
                else
                {
                    Console.WriteLine("Perks cant be null");
                }
            }
        }

        public GeneralManager(string name, decimal basic, short deptNo, string? designation, string? perks) :base(name, basic, deptNo, designation) 
        { 
            Perks = perks;
        }

        public override decimal netSalary() 
        {
            decimal percent = 1.1m;
            decimal total = Decimal.Multiply(Basic, percent);
            return total;
        }

        public new void Delete()
        {
            Console.WriteLine("Class3 - IDb.Delete");
        }

        public new void Insert()
        {
            Console.WriteLine("Class3 - IDb.Insert");
        }

        public new void Update()
        {
            Console.WriteLine("Class3 - IDb.Update");
        }
    }


    public class CEO : Employee,IDbFunctions
    { 
        public CEO(string name, decimal basic, short deptNo) : base(name, basic, deptNo)
            { }

        public sealed override decimal netSalary()
        {
            decimal percent = 1.1m;
            decimal total = Decimal.Multiply(Basic, percent);
            return total;
        }

        public new void Delete()
        {
            Console.WriteLine("Class4 - IDb.Delete");
        }

        public new void Insert()
        {
            Console.WriteLine("Class4 - IDb.Insert");
        }

        public new void Update()
        {
            Console.WriteLine("Class4 - IDb.Update");
        }
    }

    

}