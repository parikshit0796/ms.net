﻿using System.Runtime.InteropServices;

namespace Assignment_4C
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool flag = true;
            SortedList<int, Employee> objDictionary = new SortedList<int, Employee>();
            do
            {
                Console.Write("Enter Id :");
                int EmpId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter name :");
                string? Name = Console.ReadLine();
                Console.Write("Enter salary :");
                decimal Basic = Convert.ToDecimal(Console.ReadLine());
                Console.Write("Enter department no. :");
                short DeptNo = Convert.ToInt16((Console.ReadLine()));

                objDictionary.Add(EmpId, new Employee(EmpId, Name, Basic, DeptNo));

                Console.WriteLine("Select choice to Insert new employee " + "\n" + "1.Yes 2.No");
                int choice = Convert.ToInt32((Console.ReadLine()));

                if (choice == 1)
                {
                    continue;
                }
                else
                {
                    flag = false;
                }
            } while (flag);

            int count = objDictionary.Count;

            Employee[] empArr= new Employee[count]; 

            for(int j=0; j < count; j++)
            {
                empArr[j] = objDictionary.GetValueAtIndex(j);
            }

            Console.WriteLine("Employee objects stored in array are : ");
            foreach ( Employee emp in empArr )
            {
                Console.WriteLine(emp);
            }
        }

            public class Employee
        {
            public Employee(int empId, string? name, decimal basic, short deptNo)
            {
                EmpId = empId;
                Name = name;
                Basic = basic;
                DeptNo = deptNo;
            }

            private string? name;

            public string? Name
            {
                set
                {
                    if (!string.IsNullOrEmpty(value))
                    {
                        name = value.Trim();
                    }
                    else
                    {
                        Console.WriteLine("Name cant be blank...!!!!!!!!!");
                    }
                }

                get { return name; }
            }

            private int empId;
            public int EmpId
            {
                get { return empId; }
                set
                {
                    if (value > 0)
                    {
                        empId = value;
                    }
                    else
                    {
                        Console.WriteLine("Name cant be blank...!!!!!!!!!");
                    }
                }
            }

            private decimal basic;
            public decimal Basic
            {
                set
                {
                    if (value > 0 && value <= 100000)
                    {
                        basic = value;
                    }
                    else
                    {
                        Console.WriteLine("Base salary must within 0 to 100000 range");
                    }
                }
                get { return basic; }
            }

            private short deptNo;
            public short DeptNo
            {
                set
                {
                    if (value > 0)
                    {
                        deptNo = value;
                    }
                    else
                    {
                        Console.WriteLine("Department number must not be zero");
                    }
                }
                get { return deptNo; }
            }

            public override string ToString()
            {
                return "Employee ID :" + empId + " Name: " + name + " Basic Salary: " + basic + " Department ID: " + deptNo + " ";
            }

            public decimal netSalary()
            {
                decimal percent = 1.1m;
                decimal total = Decimal.Multiply(Basic, percent);
                return total;
            }

        }
    }
}