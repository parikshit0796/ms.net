﻿using System.Threading.Channels;

namespace Assignment_4B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter the size of array");
            //int size = Convert.ToInt32(Console.ReadLine());
            Employee[] emps = new Employee[] {
                new Employee(1, "Chandan", 123, 20 ),
                new Employee(2, "Saurabh", 871, 30 ),
                new Employee(3, "Sandeep", 561, 10 ),
            };

            //for(int i = 0; i < size; i++)
            //{
            //    emps [i] = new Employee { EmpId=1, Name="Chandan", Basic=123, DeptNo=20};
            //}

            List<Employee> list = new List<Employee>(emps);
            foreach (Employee emp in list)
            {
                Console.WriteLine( emp.Name + " " + emp.EmpId + " " + emp.Basic +" "+ emp.DeptNo);
            }
        }
    }

    public class Employee
    {
              public Employee(int empId, string? name, decimal basic, short deptNo)
        {
            EmpId = empId;
            Name = name;
            Basic = basic;
            DeptNo = deptNo;
        }

        private string? name;

        public string? Name
        {
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    name = value.Trim();
                }
                else
                {
                    Console.WriteLine("Name cant be blank...!!!!!!!!!");
                }
            }

            get { return name; }
        }

        private int empId;
        public int EmpId
        {
            get { return empId; }
            set
            {
                if (value > 0)
                {
                    empId = value;
                }
                else
                {
                    Console.WriteLine("Name cant be blank...!!!!!!!!!");
                }
            }
        }

        private decimal basic;
        public decimal Basic
        {
            set
            {
                if (value > 0 && value <= 100000)
                {
                    basic = value;
                }
                else
                {
                    Console.WriteLine("Base salary must within 0 to 100000 range");
                }
            }
            get { return basic; }
        }

        private short deptNo;
        public short DeptNo
        {
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    Console.WriteLine("Department number must not be zero");
                }
            }
            get { return deptNo; }
        }

        public override string ToString()
        {
            return "Employee ID :" + empId + " Name: " + name + " Basic Salary: " + basic + " Department ID: " + deptNo + " ";
        }

        public decimal netSalary()
        {
            decimal percent = 1.1m;
            decimal total = Decimal.Multiply(Basic, percent);
            return total;
        }

    }

}